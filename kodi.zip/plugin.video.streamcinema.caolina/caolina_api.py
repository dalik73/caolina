# -*- coding: utf-8 -*-
"""
caolina_api.py – Integrace s Caolina.zone API (api.caolina.zone)
================================================================
Tento modul propojuje Kodi plugin s centrálním backendem na caolina.zone.

Funkce:
  - Registrace / přihlášení uživatele na caolina.zone
  - Uložení Webshare tokenu na server (VIP sync)
  - Nahrávání a stahování historie přehrávání ze serveru
  - Reportování streamu (statistiky)

Použití:
  import caolina_api as capi
  capi.set_api_key(addon.getSetting('caolina_api_key'))
  capi.report_play(ident, title, media_type='movie', tmdb_id='12345')
  history = capi.get_history()
"""

try:
    import urllib2 as _urllib2
    from urllib import urlencode as _urlencode
except ImportError:
    import urllib.request as _urllib2
    from urllib.parse import urlencode as _urlencode

import json, xbmc

# ────────────────────────────────────────────────────────────────────────────
#  Konfigurace
# ────────────────────────────────────────────────────────────────────────────

BASE_URL = 'https://api.caolina.zone'
TIMEOUT  = 8          # sekundy

_api_key  = None      # nastavit přes set_api_key()

# ────────────────────────────────────────────────────────────────────────────
#  Vnitřní HTTP helper
# ────────────────────────────────────────────────────────────────────────────

def _request(method, path, data=None):
    """
    Pošle HTTP požadavek na Caolina API.
    Vrátí dict odpovědi nebo None při chybě.
    """
    url = BASE_URL + path
    headers = {
        'Content-Type': 'application/json',
        'User-Agent':   'StreamCinemaCaolina-Kodi/2.1',
    }
    if _api_key:
        headers['X-API-Key'] = _api_key

    try:
        body = json.dumps(data).encode('utf-8') if data else None

        req = _urllib2.Request(url, body, headers)
        req.get_method = lambda: method.upper()

        try:
            resp = _urllib2.urlopen(req, timeout=TIMEOUT)
        except Exception as e:
            xbmc.log('CaolinaAPI HTTP error [%s %s]: %s' % (method, path, e), xbmc.LOGWARNING)
            return None

        raw = resp.read()
        return json.loads(raw.decode('utf-8')) if raw else None

    except Exception as e:
        xbmc.log('CaolinaAPI error [%s %s]: %s' % (method, path, e), xbmc.LOGWARNING)
        return None


def _get(path):
    return _request('GET', path)


def _post(path, data):
    return _request('POST', path, data)


def _delete(path):
    return _request('DELETE', path)

# ────────────────────────────────────────────────────────────────────────────
#  Veřejné API
# ────────────────────────────────────────────────────────────────────────────

def set_api_key(key):
    """Zastaralé — ponecháno pro zpětnou kompatibilitu."""
    pass


def is_configured():
    """Vždy True — server funguje bez API klíče."""
    return True


# ── Registrace / přihlášení ──────────────────────────────────────────────────

def register(username, email, password):
    """
    Zaregistruje nového uživatele na caolina.zone.
    Vrátí dict s 'api_key' nebo None při chybě.

    Příklad:
        result = capi.register('jarda', 'jarda@email.cz', 'heslo123')
        if result:
            addon.setSetting('caolina_api_key', result['api_key'])
    """
    resp = _post('/api/auth/register', {
        'username': username,
        'email':    email,
        'password': password,
    })
    if resp and resp.get('data'):
        return resp['data']
    return None


def login(username, password):
    """
    Přihlásí uživatele a vrátí dict s 'api_key'.
    
    Příklad:
        result = capi.login('jarda', 'heslo123')
        if result:
            addon.setSetting('caolina_api_key', result['api_key'])
    """
    resp = _post('/api/auth/login', {
        'username': username,
        'password': password,
    })
    if resp and resp.get('data'):
        return resp['data']
    return None


def connect_webshare(ws_username, ws_password):
    """Připojí Webshare účet — fallback přes username+password."""
    resp = _post('/api/auth/webshare/connect', {
        'username': ws_username,
        'password': ws_password,
    })
    return resp.get('data') if resp else None


def connect_webshare_token(ws_token, ws_username=''):
    """
    Připojí Webshare účet přímým předáním tokenu.
    Toto je preferovaná metoda — token plugin již má po přihlášení.
    """
    resp = _post('/api/auth/webshare/connect', {
        'ws_token': ws_token,
        'username': ws_username,
    })
    return resp.get('data') if resp else None


# ── Uživatelský profil ───────────────────────────────────────────────────────

def get_profile():
    """
    Vrátí profil přihlášeného uživatele včetně VIP statusu.
    
    Vrací dict:
        {
          'id': 5,
          'username': 'jarda',
          'is_vip': True,
          'vip_until': '2026-12-31 00:00:00',
          'webshare_username': 'jarda_ws',
          ...
        }
    """
    resp = _get('/api/users/me')
    return resp.get('data') if resp else None


# ── Historie přehrávání ──────────────────────────────────────────────────────

def report_play(ident, title, file_name='', file_size=0,
                media_type='movie', tmdb_id=None,
                season=None, episode=None, ws_token=''):
    """
    Zaznamená přehrání na server — volá se AUTOMATICKY při každém play.
    Ukládá do watch_history + stream_stats (s geolokací IP).
    Sdílí statistiky mezi všemi uživateli (popularity ranking).
    """

    payload = {
        'ident':      ident,
        'title':      title,
        'file_name':  file_name or title,
        'file_size':  int(file_size) if file_size else 0,
        'media_type': media_type,
        'tmdb_id':    tmdb_id or '',
        'ws_token':   ws_token or '',
    }
    if season is not None:  payload['season']  = int(season)
    if episode is not None: payload['episode'] = int(episode)

    resp = _post('/api/search/play', payload)
    return bool(resp and resp.get('data', {}).get('recorded'))


def _legacy_report_play(ident, title, media_type='movie', tmdb_id=None,
                season=None, episode=None):
    """Stará verze — zachována pro zpětnou kompatibilitu."""

    media_id = ('tmdb_%s' % tmdb_id) if tmdb_id else ('ws_%s' % ident)

    resp = _post('/api/media/played/%s' % media_id, {
        'media_type': media_type,
        'title':      title,
        'season':     season,
        'episode':    episode,
        'stream_id':  ident,
    })
    return resp


def report_stream(ident, file_name, file_size=None):
    """
    Zaznamená stream do statistik (stream_stats tabulka).
    Volat po získání stream linku.

    Příklad:
        capi.report_stream('abc123', 'Matrix.1999.1080p.mkv', 8589934592)
    """
    return _post('/api/stream/report/%s' % ident, {
        'file_name': file_name,
        'file_size': file_size,
    })


def get_history(limit=50, offset=0):
    """
    Stáhne historii přehrávání ze serveru.
    Vrátí seznam dict nebo prázdný seznam.

    Příklad:
        history = capi.get_history(limit=100)
        for item in history:
            print(item['media_title'], item['watched_at'])
    """
    resp = _get('/api/users/me/history?limit=%d&offset=%d' % (limit, offset))
    if resp and isinstance(resp.get('data'), list):
        return resp['data']
    return []


def clear_history():
    """Vymaže celou historii přehrávání na serveru."""
    resp = _delete('/api/users/me/history')
    return bool(resp)


def delete_history_item(history_id):
    """Smaže konkrétní záznam z historie."""
    resp = _delete('/api/users/me/history/%s' % history_id)
    return bool(resp)


# ── Vyhledávání ─────────────────────────────────────────────────────────────

def search_media(query, limit=50):
    """
    Vyhledá soubory přes Webshare (server použije uložený WS token).
    
    POZNÁMKA: Tato metoda vyžaduje, že má uživatel připojený
    Webshare účet na caolina.zone (viz connect_webshare()).
    Pokud ne, vrátí prázdný seznam a plugin použije lokální WS token.

    Vrací seznam dict:
        [{'ident': 'abc', 'name': 'Matrix.mkv', 'size': 8000000000}, ...]
    """
    resp = _get('/api/media/filter/v2/search?query=%s&limit=%d' % (
        _url_encode(query), limit))
    if resp and isinstance(resp.get('data'), list):
        return resp['data']
    return []


def get_stream_link(ident, device_uuid=None):
    """
    Získá přímý stream link ze serveru (server použije uložený WS token).

    POZNÁMKA: Pokud není Webshare připojen na serveru, plugin
    použije lokální WS token přímo (fallback chování zůstává).

    Vrátí URL string nebo None.
    """
    path = '/api/stream?ident=%s' % ident
    if device_uuid:
        path += '&device_uuid=%s' % device_uuid
    resp = _get(path)
    if resp and resp.get('data', {}).get('link'):
        return resp['data']['link']
    return None


# ── Utility ──────────────────────────────────────────────────────────────────

def _url_encode(s):
    """URL-enkóduje string."""
    try:
        from urllib import quote_plus
        return quote_plus(s.encode('utf-8'))
    except ImportError:
        from urllib.parse import quote_plus
        return quote_plus(s)


# ── Metadata (server-side TMDB + CSFD + OMDB) ────────────────────────────────

def search_movies(query, page=1):
    """
    Vyhledá filmy přes server (TMDB + CSFD fallback, výsledky v češtině).
    Vrátí dict: {'results': [...], 'total_pages': N}
    Každý výsledek: {'tmdb_id', 'title', 'orig_title', 'year', 'plot',
                     'poster', 'backdrop', 'genres', 'type', 'source'}
    """
    resp = _get('/api/metadata/search?q=%s&type=movie&page=%d' % (_url_encode(query), page))
    if resp and resp.get('data'):
        return resp['data'].get('results', []), resp['data'].get('total_pages', 1)
    return [], 1


def search_tvshows(query, page=1):
    """Vyhledá seriály přes server."""
    resp = _get('/api/metadata/search?q=%s&type=tv&page=%d' % (_url_encode(query), page))
    if resp and resp.get('data'):
        return resp['data'].get('results', []), resp['data'].get('total_pages', 1)
    return [], 1


def get_movie_details(tmdb_id):
    """
    Vrátí detail filmu ze serveru (TMDB + OMDB + CSFD rating).
    Vrátí dict nebo None.
    """
    resp = _get('/api/metadata/movie/%s' % tmdb_id)
    return resp.get('data') if resp else None


def get_tvshow_details(tmdb_id):
    """Vrátí detail seriálu ze serveru."""
    resp = _get('/api/metadata/tv/%s' % tmdb_id)
    return resp.get('data') if resp else None


def get_season(tmdb_id, season_number):
    """
    Vrátí detaily sezóny (seznam epizod).
    Vrátí dict: {'season_number', 'name', 'episodes': [...], 'poster'}
    """
    resp = _get('/api/metadata/tv/%s/season/%d' % (tmdb_id, int(season_number)))
    return resp.get('data') if resp else None


def get_trending(media_type='movie', time_window='week'):
    """Vrátí trendující filmy/seriály."""
    resp = _get('/api/metadata/trending?type=%s&window=%s' % (media_type, time_window))
    if resp and resp.get('data'):
        return resp['data'].get('results', [])
    return []


def get_popular(media_type='movie', page=1):
    """Vrátí populární filmy/seriály."""
    resp = _get('/api/metadata/popular?type=%s&page=%d' % (media_type, page))
    if resp and resp.get('data'):
        d = resp['data']
        return d.get('results', []), d.get('total_pages', 1)
    return [], 1


def discover(media_type='movie', genre_id='', year='', country_code='',
             sort_by='popularity.desc', page=1):
    """Discover filmy/seriály podle parametrů."""
    path = '/api/metadata/discover?type=%s&page=%d&sort=%s' % (media_type, page, sort_by)
    if genre_id:     path += '&genre=%s' % genre_id
    if year:         path += '&year=%s' % year
    if country_code: path += '&country=%s' % country_code
    resp = _get(path)
    if resp and resp.get('data'):
        d = resp['data']
        return d.get('results', []), d.get('total_pages', 1)
    return [], 1


def get_genres(media_type='movie'):
    """Vrátí list žánrů: [{'id': 28, 'name': 'Akční'}, ...]"""
    resp = _get('/api/metadata/genres?type=%s' % media_type)
    if resp and isinstance(resp.get('data'), list):
        return [(g['id'], g['name']) for g in resp['data']]
    return []



def get_menu(ws_token='', ws_username=''):
    """
    Načte strukturu menu ze serveru.
    Vrátí list položek nebo None pokud server není dostupný.
    """
    try:
        from urllib import urlencode
    except ImportError:
        from urllib.parse import urlencode

    params = {}
    if ws_token:
        params['ws_token'] = ws_token
    if ws_username:
        params['ws_username'] = ws_username

    query = urlencode(params)
    endpoint = '/api/menu' + ('?' + query if query else '')

    resp = _get(endpoint)
    if resp is None:
        return None  # Server nedostupný — doplněk zobrazí chybu
    if not isinstance(resp, dict):
        return None
    menu = resp.get('menu', resp.get('data', {}).get('menu', None))
    if menu is None:
        return None
    return menu


def server_search(query, ws_token, media_type='movie', page=1, ws_username=''):
    """
    Vyhledávání přes server — server prohledá WS, spáruje s TMDB, uloží do sdílené cache.
    Vrátí {'results': [...], 'source': 'cache'|'webshare', 'total': N}
    Každý výsledek má: tmdb_id, title, orig_title, year, plot, poster, files[], best_file{}
    """
    payload = {
        'q':           query,
        'type':        media_type,
        'page':        page,
        'ws_token':    ws_token,
        'ws_username': ws_username,
    }
    resp = _post('/api/search', payload)
    if resp and resp.get('data'):
        return resp['data']
    return {'results': [], 'source': 'error', 'total': 0}

def get_best_match(tmdb_id, media_type='movie', season=None, episode=None):
    """
    Vrátí uložený best-match WS soubor pro daný TMDB ID (z cache serveru).
    Vrátí dict s 'files' a 'score' nebo None.
    """
    path = '/api/search/match?tmdb_id=%s&type=%s' % (tmdb_id, media_type)
    if season is not None:  path += '&season=%d' % season
    if episode is not None: path += '&episode=%d' % episode
    resp = _get(path)
    return resp.get('data') if resp else None
